import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NavbarApp from "./components/Navbar";
import FooterApp from "./components/Footer";
import Home from "./pages/Home";
import NewItem from "./pages/NewItem";
import EditItem from "./pages/EditItem";
import Detail from "./pages/Detail";

function App() {
  return (
    <Router>
      <div className="d-flex flex-column min-vh-100">
        <NavbarApp />
        <div className="flex-grow-1 container mt-4">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/nuevo" element={<NewItem />} />
            <Route path="/editar/:id" element={<EditItem />} />
            <Route path="/detalle/:id" element={<Detail />} />
          </Routes>
        </div>
        <FooterApp />
      </div>
    </Router>
  );
}

export default App;