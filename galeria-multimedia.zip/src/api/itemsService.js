import { v4 as uuidv4 } from "uuid";
import sampleData from "../data/sampleData";

const STORAGE_KEY = "galeria_items_v1";

function loadData() {
  const data = localStorage.getItem(STORAGE_KEY);
  if (data) return JSON.parse(data);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(sampleData));
  return sampleData;
}

export function getAll() {
  return loadData();
}

export function getById(id) {
  return loadData().find((item) => item.id === id);
}

export function create(item) {
  const data = loadData();
  const newItem = { ...item, id: uuidv4(), createdAt: new Date().toISOString() };
  data.push(newItem);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  return newItem;
}

export function update(id, updatedItem) {
  let data = loadData();
  data = data.map((item) => (item.id === id ? { ...item, ...updatedItem } : item));
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

export function remove(id) {
  let data = loadData();
  data = data.filter((item) => item.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}