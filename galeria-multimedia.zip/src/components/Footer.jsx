import React from "react";

function FooterApp() {
  return (
    <footer className="bg-dark text-light text-center py-3 mt-4">
      <p>Galería Multimedia © 2025 - Proyecto CRUD en React</p>
    </footer>
  );
}
export default FooterApp;