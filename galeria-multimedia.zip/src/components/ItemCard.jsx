import React from "react";
import { Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

function ItemCard({ item, onDelete }) {
  return (
    <Card className="h-100">
      {item.type === "photo" ? (
        <Card.Img variant="top" src={item.url} alt={item.title} style={{ height: "200px", objectFit: "cover" }} />
      ) : (
        <video controls style={{ width: "100%", height: "200px", objectFit: "cover" }}>
          <source src={item.url} type="video/mp4" />
        </video>
      )}
      <Card.Body>
        <Card.Title>{item.title}</Card.Title>
        <Card.Text>{item.description.slice(0, 60)}...</Card.Text>
        <Card.Text><strong>${item.price}</strong></Card.Text>
        <Button as={Link} to={`/detalle/${item.id}`} variant="primary" className="me-2">Ver</Button>
        <Button as={Link} to={`/editar/${item.id}`} variant="warning" className="me-2">Editar</Button>
        <Button onClick={() => onDelete(item.id)} variant="danger">Eliminar</Button>
      </Card.Body>
    </Card>
  );
}
export default ItemCard;