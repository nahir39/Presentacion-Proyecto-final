import React from "react";
import { useForm } from "react-hook-form";
import { Form, Button } from "react-bootstrap";

function ItemForm({ initialData = {}, onSubmit }) {
  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues: initialData
  });

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Form.Group className="mb-3">
        <Form.Label>Título</Form.Label>
        <Form.Control {...register("title", { required: "El título es obligatorio" })} />
        {errors.title && <span className="text-danger">{errors.title.message}</span>}
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Descripción</Form.Label>
        <Form.Control as="textarea" rows={3} {...register("description")} />
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Tipo</Form.Label>
        <Form.Select {...register("type", { required: "Seleccione un tipo" })}>
          <option value="">Seleccione...</option>
          <option value="photo">Foto</option>
          <option value="video">Video</option>
        </Form.Select>
        {errors.type && <span className="text-danger">{errors.type.message}</span>}
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>URL</Form.Label>
        <Form.Control {...register("url", { required: "La URL es obligatoria" })} />
        {errors.url && <span className="text-danger">{errors.url.message}</span>}
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Precio</Form.Label>
        <Form.Control type="number" {...register("price", { min: 0 })} />
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Categoría</Form.Label>
        <Form.Control {...register("category")} />
      </Form.Group>

      <Button type="submit" variant="success">Guardar</Button>
    </Form>
  );
}
export default ItemForm;