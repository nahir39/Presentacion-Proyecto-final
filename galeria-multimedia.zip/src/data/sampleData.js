export default [
  {
    id: "1",
    title: "Atardecer en la playa",
    description: "Foto de un atardecer hermoso en la costa.",
    type: "photo",
    url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
    price: 0,
    category: "Naturaleza",
    createdAt: "2025-09-30T12:00:00Z"
  },
  {
    id: "2",
    title: "Video de cascada",
    description: "Un video corto de una cascada en la montaña.",
    type: "video",
    url: "https://www.w3schools.com/html/mov_bbb.mp4",
    price: 5,
    category: "Naturaleza",
    createdAt: "2025-09-30T12:00:00Z"
  },
  {
    id: "3",
    title: "Ciudad nocturna",
    description: "Luces de la ciudad de noche.",
    type: "photo",
    url: "https://images.unsplash.com/photo-1505761671935-60b3a7427bad",
    price: 10,
    category: "Urbano",
    createdAt: "2025-09-30T12:00:00Z"
  }
];