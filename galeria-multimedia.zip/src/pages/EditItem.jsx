import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import ItemForm from "../components/ItemForm";
import { getById, update } from "../api/itemsService";

function EditItem() {
  const { id } = useParams();
  const navigate = useNavigate();
  const item = getById(id);

  const handleSubmit = (data) => {
    update(id, data);
    navigate("/");
  };

  if (!item) return <p>Ítem no encontrado</p>;

  return (
    <div>
      <h2>Editar Ítem</h2>
      <ItemForm initialData={item} onSubmit={handleSubmit} />
    </div>
  );
}
export default EditItem;