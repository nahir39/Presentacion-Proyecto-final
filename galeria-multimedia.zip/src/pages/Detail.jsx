import React from "react";
import { useParams } from "react-router-dom";
import { getById } from "../api/itemsService";

function Detail() {
  const { id } = useParams();
  const item = getById(id);

  if (!item) return <p>Ítem no encontrado</p>;

  return (
    <div>
      <h2>{item.title}</h2>
      <p>{item.description}</p>
      {item.type === "photo" ? (
        <img src={item.url} alt={item.title} className="img-fluid" />
      ) : (
        <video controls style={{ width: "100%" }}>
          <source src={item.url} type="video/mp4" />
        </video>
      )}
      <p><strong>Precio:</strong> ${item.price}</p>
      <p><strong>Categoría:</strong> {item.category}</p>
    </div>
  );
}
export default Detail;