import React from "react";
import { useNavigate } from "react-router-dom";
import ItemForm from "../components/ItemForm";
import { create } from "../api/itemsService";

function NewItem() {
  const navigate = useNavigate();

  const handleSubmit = (data) => {
    create(data);
    navigate("/");
  };

  return (
    <div>
      <h2>Subir Nuevo Ítem</h2>
      <ItemForm onSubmit={handleSubmit} />
    </div>
  );
}
export default NewItem;