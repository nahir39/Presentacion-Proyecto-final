import React, { useState, useEffect } from "react";
import { Row, Col } from "react-bootstrap";
import ItemCard from "../components/ItemCard";
import { getAll, remove } from "../api/itemsService";

function Home() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    setItems(getAll());
  }, []);

  const handleDelete = (id) => {
    remove(id);
    setItems(getAll());
  };

  return (
    <div>
      <h2>Galería de Fotos y Videos</h2>
      <Row className="g-4 mt-2">
        {items.map((item) => (
          <Col key={item.id} sm={12} md={6} lg={4}>
            <ItemCard item={item} onDelete={handleDelete} />
          </Col>
        ))}
      </Row>
    </div>
  );
}
export default Home;